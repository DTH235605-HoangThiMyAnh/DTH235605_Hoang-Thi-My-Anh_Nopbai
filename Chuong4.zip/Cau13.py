def sum_of_divisors(n):
    total = 1
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            total += i
            if i != n // i:
                total += n // i
    return total if n > 1 else 0
#kiểm tra số hoàn thiện
def is_perfect(n):
    return sum_of_divisors(n) == n
#kiểm tra số thịnh vượng
def is_abundant(n):
    return sum_of_divisors(n) > n

# Dùng thử
for n in range(1, 31):
    print(f"{n}: Perfect? {is_perfect(n)}, Abundant? {is_abundant(n)}")